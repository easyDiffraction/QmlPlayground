# qmlplot

This is a wrapper to QCustomPlot to render by QtQuick2.
Implemented [solution from QCustomPlot forum](http://www.qcustomplot.com/index.php/support/forum/172).
